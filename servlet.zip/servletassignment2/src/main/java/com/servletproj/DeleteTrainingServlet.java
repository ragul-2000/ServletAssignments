package com.servletproj;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DeleteTrainingServlet")
public class DeleteTrainingServlet extends HttpServlet {
private static final long serialVersionUID = 1L;

public DeleteTrainingServlet() {
    super();
}

protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    int trainingId = Integer.parseInt(request.getParameter("trainingId"));
    try {
        Connection conn = DbUtil.getConnection();
        PreparedStatement st = conn.prepareStatement("DELETE FROM training_programs WHERE training_id=?");
        st.setInt(1, trainingId);
        st.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
    response.sendRedirect("AdminHome.jsp");
}
}